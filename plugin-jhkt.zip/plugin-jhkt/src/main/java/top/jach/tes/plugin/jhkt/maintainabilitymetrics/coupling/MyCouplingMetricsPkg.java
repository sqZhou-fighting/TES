package top.jach.tes.plugin.jhkt.maintainabilitymetrics.coupling;

import org.eclipse.jgit.util.io.LimitedInputStream;
import top.jach.tes.core.impl.domain.element.Element;
import top.jach.tes.plugin.jhkt.microservice.ElementCouplingParams;
import top.jach.tes.plugin.jhkt.microservice.Microservice;
import top.jach.tes.plugin.jhkt.microservice.MicroservicesInfo;
import top.jach.tes.plugin.jhkt.microservice.Pkg;

import java.util.*;

/**
 * @Author: zhoushiqi
 * @date: 2020/10/21
 * @description: 947 自己设计的关于耦合的和指标，主要是微服务之间的包调用所构成的耦合
 */
public class MyCouplingMetricsPkg {
    public static Set<ElementCouplingParams> extraServiceIncomingCouplingOfE(String pkgName,
                                                                              MicroservicesInfo microservicesInfo) {
        // 有一个待确定的问题是：Pkg类中的pkgName与pkgPath都分别表示什么呢？
        // 本方法的前提假设是：pkgName为go文件中import所写明的就是包名
        Set<ElementCouplingParams> incomingCouplingE = new HashSet<>();
        for (Microservice microservice : microservicesInfo.getMicroservices()) {
            for (Pkg pkg : microservice.getPkgs()) {
                for (Map.Entry<String, List<String>> entry : pkg.getInvokedPkgs().entrySet()) {
                    for (String pkg_name : entry.getValue()) {
                        if (pkg_name.equals(pkgName)) {
                            incomingCouplingE.add(new ElementCouplingParams(pkgName, microservice.getElementName()));
                        }
                    }
                }
            }
        }
        return incomingCouplingE;
    }

    public static Set<ElementCouplingParams> extraServiceOutgoingCouplingOfE(String pkgName,
                                                                              MicroservicesInfo microservicesInfo){
        // 本方法的前提假设是：pkgName为go文件中import所写明的就是包名
        Set<ElementCouplingParams> outgoingCouplingE = new HashSet<>();
        for (Microservice microservice : microservicesInfo.getMicroservices()){
            for (Pkg pkg : microservice.getPkgs()){
                if (pkg.getPkgName().equals(pkgName)){
                    for (Map.Entry<String, List<String>> entry : pkg.getInvokedPkgs().entrySet()){
                        for (String pkg_name : entry.getValue()){
                            outgoingCouplingE.add(new ElementCouplingParams(pkg_name, microservice.getElementName()));
                        }
                    }
                }
            }
        }
        return outgoingCouplingE;
    }

    public static Set<ElementCouplingParams> totalExtraServiceCouplingOfE(String pkgName,
                                                                          MicroservicesInfo microservicesInfo){
        Set<ElementCouplingParams> totalCouplingE = new HashSet<>();
        totalCouplingE.addAll(extraServiceIncomingCouplingOfE(pkgName, microservicesInfo));
        totalCouplingE.addAll(extraServiceOutgoingCouplingOfE(pkgName, microservicesInfo));
        return totalCouplingE;
    }

    public static Set<ElementCouplingParams> extraServiceIncomingCouplingOfS(String microserviceName,
                                                                             MicroservicesInfo microservicesInfo){
        Set<ElementCouplingParams> IncomingCoupingS = new HashSet<>();
        for (Microservice microservice : microservicesInfo.getMicroservices()){
            if (microservice.getElementName().equals(microserviceName)){
                for (Pkg pkg : microservice.getPkgs()){
                    IncomingCoupingS.addAll(extraServiceIncomingCouplingOfE(pkg.getPkgName(), microservicesInfo));
                }
            }
        }
        return IncomingCoupingS;
    }

    public static Set<ElementCouplingParams> extraServiceOutgoingCouplingOfS(String microserviceName,
                                                                             MicroservicesInfo microservicesInfo){
        Set<ElementCouplingParams> OutgoingCouplingS = new HashSet<>();
        for (Microservice microservice : microservicesInfo.getMicroservices()){
            if (microservice.getElementName().equals(microserviceName)){
                for (Pkg pkg : microservice.getPkgs()){
                    OutgoingCouplingS.addAll(extraServiceOutgoingCouplingOfE(pkg.getPkgName(), microservicesInfo));
                }
            }
        }
        return OutgoingCouplingS;
    }

    public static Set<ElementCouplingParams> totalExtraServiceCouplingOfS(String microserviceName,
                                                                          MicroservicesInfo microservicesInfo){
        Set<ElementCouplingParams> totalCouplingS = new HashSet<>();
        totalCouplingS.addAll(extraServiceIncomingCouplingOfS(microserviceName, microservicesInfo));
        totalCouplingS.addAll(extraServiceOutgoingCouplingOfS(microserviceName, microservicesInfo));
        return totalCouplingS;
    }

}

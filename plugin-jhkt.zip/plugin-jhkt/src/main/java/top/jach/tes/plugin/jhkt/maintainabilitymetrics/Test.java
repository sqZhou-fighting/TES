package top.jach.tes.plugin.jhkt.maintainabilitymetrics;

import java.text.DecimalFormat;

/**
 * @Author: zhoushiqi
 * @date: 2020/8/28
 */
public class Test {
    public static void main(String[] args) {
        /*List<String> tmp = null;
        System.out.println(tmp == null);
        tmp = new ArrayList<>();
        System.out.println(tmp == null);
        System.out.println(tmp.size());*/

//        System.out.println(Math.log((1.0/3.0)*2));
        DecimalFormat df = new DecimalFormat( "0.0000");
        System.out.println(df.format(test()));
    }

    public static double test(){

        return (2*1.0)/3;
    }
}

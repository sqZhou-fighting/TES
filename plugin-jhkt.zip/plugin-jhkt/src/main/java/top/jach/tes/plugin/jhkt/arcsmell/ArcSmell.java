package top.jach.tes.plugin.jhkt.arcsmell;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ArcSmell {
    Long hublink;
    Long hublinkForIn;
    Long hublinkForOut;
    Long cyclic;
    Long mv;
//    Long mvWeight;
}

package top.jach.tes.plugin.jhkt.utils;

public class JhktInfoTools {
}

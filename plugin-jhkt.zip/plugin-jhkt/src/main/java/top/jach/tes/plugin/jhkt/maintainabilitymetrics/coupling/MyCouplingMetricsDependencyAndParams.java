package top.jach.tes.plugin.jhkt.maintainabilitymetrics.coupling;

import lombok.NoArgsConstructor;
import top.jach.tes.plugin.jhkt.maintainabilitymetrics.utils.DependencyUtil;
import top.jach.tes.plugin.jhkt.maintainabilitymetrics.utils.TopicUtil;
import top.jach.tes.plugin.jhkt.microservice.Microservice;
import top.jach.tes.plugin.jhkt.microservice.MicroservicesInfo;
import top.jach.tes.plugin.jhkt.microservice.TopicStruct;
import top.jach.tes.plugin.tes.code.dependency.model.CSPair;

import java.util.List;
import java.util.Map;

/**
 * @Author: zhoushiqi
 * @date: 2020/10/22
 * @description: 基于MyCouplingMetricsDependency中的指标添加了参数所包含的信息量的影响
 * 要根据依赖中的topic名字找到其参数，所以先要对多有微服务中的topicStruct做一个统计，拿到系统所有topic
 */

public class MyCouplingMetricsDependencyAndParams {

    // 整合时需要初始化
    public static MicroservicesInfo microservicesInfo;
    private static Map<String, Integer> topics = TopicUtil.getAllTopic(microservicesInfo);
    // 整合时需要初始化,这个Dependencies就是成对的那种，不是DependencyUtil中的只要Req的
    private static List<CSPair> allDependencies;

    public static double incomingCouplingOfSByDependencyAndParams(String microserviceName) {
        double res = 0;
        for (CSPair csPair : allDependencies) {
            double tmp = 0;
            if (csPair.getReq().getDest_cs().equals(microserviceName)) {
                tmp = topics.get(csPair.getReq().getTopic()) * 0.1;
                if (csPair.getRsp() != null) {
                    tmp = (tmp + topics.get(csPair.getRsp().getTopic()) * 0.1) * 2;
                }
            }
            res += tmp;
        }
        return res;
    }

    public static double outgoingCouplingOfSByDependencyAndParams(String microserviceName) {
        double res = 0;

        for (CSPair csPair : allDependencies) {
            double tmp = 0;
            if (csPair.getReq().getSrc_cs().equals(microserviceName)) {
                tmp += topics.get(csPair.getReq().getTopic()) * 0.1;
                if (csPair.getRsp() != null) {
                    tmp = (tmp + topics.get(csPair.getRsp().getTopic()) * 0.1) * 2;
                }
            }
            res += tmp;
        }
        return res;
    }

    public static double totalCouplingOfSByDependencyAndParams(String microserviceName) {
        double res1 = 0;
        double res2 = 0;
        for (CSPair csPair : allDependencies) {
            double tmp1 = 0;
            double tmp2 = 0;
            if (csPair.getReq().getSrc_cs().equals(microserviceName)) {
                tmp1 += topics.get(csPair.getReq().getTopic()) * 0.1;
                if (csPair.getRsp() != null) {
                    tmp1 = (tmp1 + topics.get(csPair.getRsp().getTopic()) * 0.1) * 2;
                }
            }
            res1 += tmp1;
            if (csPair.getReq().getDest_cs().equals(microserviceName)) {
                tmp2 += topics.get(csPair.getReq().getTopic()) * 0.1;
                if (csPair.getRsp() != null) {
                    tmp2 = (tmp2 + topics.get(csPair.getRsp().getTopic()) * 0.1) * 2;
                }
            }
            res2 += tmp2;
        }
        return res1 + res2;
    }

    public static double callsCouplingInServicePairAndParams(String microserviceName1,
                                                             String microserviceName2) {

        double res1 = 0.0;
        double res2 = 0.0;

        for (CSPair csPair : allDependencies) {
            double tmp1 = 0.0;
            double tmp2 = 0.0;
            if (csPair.getReq().getSrc_cs().equals(microserviceName1) &&
                    csPair.getReq().getDest_cs().equals(microserviceName2)) {
                tmp1 = topics.get(csPair.getReq().getTopic()) * 0.1;
                if (csPair.getRsp() != null) {
                    tmp1 = (tmp1 + topics.get(csPair.getRsp().getTopic()) * 0.1) * 2;
                }
                res1 += tmp1;
            }
            if (csPair.getReq().getDest_cs().equals(microserviceName1) &&
                    csPair.getReq().getSrc_cs().equals(microserviceName2)) {
                tmp2 = topics.get(csPair.getReq().getTopic()) * 0.1;
                if (csPair.getRsp() != null) {
                    tmp2 = (tmp2 + topics.get(csPair.getRsp().getTopic()) * 0.1) * 2;
                }
                res2 += tmp2;
            }
        }
        return res1 != 0.0 && res2 != 0.0 ? (res1 + res2) * 1.5 : (res1 + res2);
    }


}

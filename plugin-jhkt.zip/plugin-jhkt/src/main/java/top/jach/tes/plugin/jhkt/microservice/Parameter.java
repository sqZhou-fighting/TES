package top.jach.tes.plugin.jhkt.microservice;

/**
 * @Author: zhoushiqi
 * @date: 2020/6/28
 */
public enum Parameter {
    BYTE, CHAR, BOOLEAN, SHORT, INTEGER, FLOAT, LONG, DOUBLE, CUSTOMIZED, COLLECTION;
}

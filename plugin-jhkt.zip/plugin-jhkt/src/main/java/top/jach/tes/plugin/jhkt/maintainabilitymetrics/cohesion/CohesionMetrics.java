package top.jach.tes.plugin.jhkt.maintainabilitymetrics.cohesion;

import com.sun.tracing.dtrace.DependencyClass;
import javafx.util.Pair;
import top.jach.tes.plugin.jhkt.microservice.Microservice;
import top.jach.tes.plugin.jhkt.microservice.TopicStruct;
import top.jach.tes.plugin.tes.code.dependency.model.CSPair;
import top.jach.tes.plugin.tes.code.microservice.Topic;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Author: zhoushiqi
 * @date: 2020/9/28
 * @description: 耦合度度量指标
 */
public class CohesionMetrics {
    //74 - Service Interface Data Cohesion
    public static double SIDC(Microservice microservice) {
        List<TopicStruct> structs = microservice.getStructs();
        int flag = structs.size();
        Map<String, Integer> paramsStatistics = new HashMap<>();
        for (TopicStruct struct : structs) {
            Map<String, String> structParams = struct.getParams();
            for (Map.Entry<String, String> entry : structParams.entrySet()) {
                if (entry.getValue().equals("oneof")) {
                    continue;
                }
                paramsStatistics.merge(entry.getValue(), 1, (oldValue, newValue) -> oldValue + newValue);
            }
            for (int i = 0; i < struct.getOneofs().size(); i++) {
                String oneofName = struct.getOneofs().get(i).getName();
                paramsStatistics.merge(oneofName, 1, (oldValue, newValue) -> oldValue + newValue);
            }
        }
        int count = 0;
        for (Map.Entry<String, Integer> entry : paramsStatistics.entrySet()) {
            if (entry.getValue() == flag) {
                count++;
            }
        }
        return (count * 1.0) / paramsStatistics.size();
    }

    // 75 - Service Interface Usage Cohesion
    public static double SIUC(Microservice microservice, List<CSPair> dependencies) {
        double res = 0.0;
        int count = 0;
        Map<String, Integer> middleRes = new HashMap<>();
        for (CSPair csPair : dependencies) {
            if (csPair.getReq().getDest_cs().equals(microservice.getElementName())) {
                middleRes.merge(csPair.getReq().getSrc_cs(), 1, (oldValue, newValue) -> (oldValue + newValue));
                count++;
            }
        }
        int flag = microservice.getSubTopics().size();
        return flag > 1 ? (count * 1.0 - middleRes.size()) / (middleRes.size() * microservice.getSubTopics().size())
                : (count * 1.0) / (middleRes.size() * microservice.getSubTopics().size());
    }

    // 105 - Total Interface Cohesion of a Service
    public static double TICS(Microservice microservice, List<CSPair> dependencies) {
        return (SIDC(microservice) + SIUC(microservice, dependencies)) / 2;
    }


}

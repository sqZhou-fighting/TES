package top.jach.tes.plugin.tes.code.microservice;

import lombok.Getter;
import lombok.Setter;

/**
 * @Author: zhoushiqi
 * @date: 2020/6/28
 */
//该类为Topic类对应的结构类
@Getter
@Setter
public class Struct {
    //struct中包含的信息待定
}

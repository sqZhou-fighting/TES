package top.jach.tes.plugin.tes.code.git.commit;

/**
 * @Author: zhoushiqi
 * @date: 2020/6/21
 */
public class Test {
    public static void main(String[] args) {
        DiffFile df = new DiffFile();
    }
}

package top.jach.tes.plugin.tes.code.git.version;

public interface WithVersion {
    Long getReposId();
    String getVerionName();
}
